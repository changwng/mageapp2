package com.example.foo.mageapp.cart.total;

import com.example.foo.mageapp.cart.CartTotal;

/**
 * Created by foo on 9/26/17.
 */

public class CartGrandTotal extends CartTotal {
    protected static final String TYPE = "grand_total";
}
