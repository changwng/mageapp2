package com.example.foo.mageapp;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.foo.mageapp.R;
import com.example.foo.mageapp.checkout.PaymentMethod;
import com.example.foo.mageapp.xmlconnect.CheckoutPaymentMethodConnect;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class CheckoutPaymentMethodFragment extends Fragment {

    protected static final String TAG = CheckoutPaymentMethodFragment.class.getSimpleName();
    protected Context mContext;
    protected List<PaymentMethod> mMethods;

    public CheckoutPaymentMethodFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setRetainInstance(true);
        mContext = this.getContext();
        new FetchPaymentMethodsTask().execute();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_checkout_payment_method, container, false);

        return v;
    }

    public static Fragment newFragment() {
        return new CheckoutPaymentMethodFragment();
    }

    protected void updateUI() {

    }

    private class FetchPaymentMethodsTask extends AsyncTask<Void, Void, List> {
        @Override
        protected List<PaymentMethod> doInBackground(Void... params) {
            List<PaymentMethod> methods = new CheckoutPaymentMethodConnect(mContext)
                    .fetchPaymentMethods();
            return methods;
        }
        @Override
        protected void onPostExecute(List result) {
            mMethods = result;
            updateUI();
        }
    }
}
