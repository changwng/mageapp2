package com.example.foo.mageapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.foo.mageapp.checkout.OrderReview;
import com.example.foo.mageapp.helper.ImgDownloader;
import com.example.foo.mageapp.sales.QuoteItem;
import com.example.foo.mageapp.xmlconnect.CheckoutReviewConnect;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class CheckoutReviewFragment extends Fragment {

    protected static final String TAG = CheckoutReviewFragment.class.getSimpleName();
    protected Context mContext;
    protected OrderReview mOrderReview;
    protected RecyclerView mItemRecyclerView;
    protected ImgDownloader<ItemViewHolder> mImgDownloader;
    protected TextView mTvTotal;

    public CheckoutReviewFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setRetainInstance(true);
        mContext = this.getContext();
        new CheckoutReviewTask().execute();

        Handler responseHandler = new Handler();
        mImgDownloader = new ImgDownloader<>(mContext, responseHandler);
        mImgDownloader.setOnDownloadListener(new ImgDownloader.OnDownloadListener<ItemViewHolder>() {
            @Override
            public void onDownloaded(ItemViewHolder holder, Bitmap bitmap) {
                Drawable drawable = new BitmapDrawable(getResources(), bitmap);
                holder.bindDrawable(drawable);
            }
        });
        mImgDownloader.start();
        mImgDownloader.getLooper();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_checkout_review, container, false);
        mItemRecyclerView = v.findViewById(R.id.checkout_review_list_item);
        LinearLayoutManager layoutMgr = new LinearLayoutManager(mContext);
        mItemRecyclerView.setLayoutManager(layoutMgr);
        mTvTotal = v.findViewById(R.id.tv_checkout_review_total);
        // set totals information below..
        // subtotal

        // shipping

        // tax

        // grand total






        return v;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mImgDownloader.clearQueue();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mImgDownloader.quit();
    }

    public static Fragment newInstance() {
        CheckoutReviewFragment f = new CheckoutReviewFragment();
        return f;
    }

    protected void updateUI() {
        ItemViewAdapter adapter = new ItemViewAdapter(mOrderReview.getProducts());
        mItemRecyclerView.setAdapter(adapter);
    }

    private class ItemViewHolder extends RecyclerView.ViewHolder {
        protected ImageView mIcon;
        protected TextView mName;
        protected TextView mQty;
        protected TextView mSubtotal;
        protected LinearLayout mOptionContainer;
        public ItemViewHolder(View view) {
            super(view);
            mIcon = view.findViewById(R.id.iv_quote_item_icon);
            mQty = view.findViewById(R.id.tv_quote_item_qty);
            mSubtotal = view.findViewById(R.id.tv_quote_item_subtotal);
            mName = view.findViewById(R.id.tv_quote_item_name);
            mOptionContainer = view.findViewById(R.id.quote_item_option_container);
        }
        public void bindItem(QuoteItem item) {
            mName.setText(item.getName());
            mQty.setText(item.getQty());
            mSubtotal.setText(item.getFormatedSubtotal());
            // set product option(s) here..




        }
        public void bindDrawable(Drawable drawable) {
            mIcon.setImageDrawable(drawable);
        }
    }

    private class ItemViewAdapter extends RecyclerView.Adapter<ItemViewHolder> {
        protected List<QuoteItem> mItems;
        public ItemViewAdapter(List<QuoteItem> items) {
            mItems = items;
        }
        @Override
        public int getItemCount() {
            return mItems.size();
        }
        @Override
        public ItemViewHolder onCreateViewHolder(ViewGroup root, int i) {
            LayoutInflater inflater = LayoutInflater.from(mContext);
            View view = inflater.inflate(R.layout.quote_list_item, root, false);
            return new ItemViewHolder(view);
        }
        @Override
        public void onBindViewHolder(ItemViewHolder holder, int pos) {
            QuoteItem item = mItems.get(pos);
            holder.bindItem(item);
            mImgDownloader.queueImg(holder, item.getIcon());
        }
    }

    private class CheckoutReviewTask extends AsyncTask<Void, Void, OrderReview> {
        @Override
        protected OrderReview doInBackground(Void... params) {
            OrderReview review = new CheckoutReviewConnect(mContext).fetccOrderReview();
            return review;
        }
        @Override
        protected void onPostExecute(OrderReview result) {
            mOrderReview = result;
            updateUI();
        }
    }
}
