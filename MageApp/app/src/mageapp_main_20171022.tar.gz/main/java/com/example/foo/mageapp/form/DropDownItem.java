package com.example.foo.mageapp.form;

/**
 * Created by foo on 10/18/17.
 */

public interface DropDownItem {
    String getItemLabel();
}
