package com.example.foo.mageapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.foo.mageapp.form.Form;
import com.example.foo.mageapp.xmlconnect.CheckoutBillingConnect;

/**
 * A simple {@link Fragment} subclass.
 */
public class CheckoutShippingFragment extends CheckoutAddressFragment {

    public CheckoutShippingFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setRetainInstance(true);
        new ShippingTask().execute();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_checkout_billing, container, false);
        mAddressForm = v.findViewById(R.id.form_billing);
        mBtSave = v.findViewById(R.id.bt_save_billing);
        return v;
    }

    public static Fragment newFragment() {
        return new CheckoutShippingFragment();
    }

    private class ShippingTask extends AsyncTask<Void, Void, Form> {
        @Override
        protected Form doInBackground(Void... params) {
            Form form = new CheckoutBillingConnect(getContext()).fetchBillingForm();
            return form;
        }

        @Override
        protected void onPostExecute(Form result) {
            mForm = result;
            updateUI();
        }
    }
}
