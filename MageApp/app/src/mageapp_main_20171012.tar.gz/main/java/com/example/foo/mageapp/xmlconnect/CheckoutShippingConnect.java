package com.example.foo.mageapp.xmlconnect;

import android.content.Context;

import com.example.foo.mageapp.form.Form;

/**
 * Created by foo on 10/7/17.
 */

public class CheckoutShippingConnect extends CheckoutAddressConnect {

    public CheckoutShippingConnect(Context c) {
        super(c);
    }

    public Form fetchBillingForm() {
        mPath = "xmlconnect/checkout/newShippingAddressForm";
        String url = this.getRequestUrl();
        String resp = getContentByUrl(url);
        return this.parseFormByXml(resp);
    }
}
