package com.example.foo.mageapp.cart;

/**
 * Created by foo on 9/6/17.
 */

public class CartItemOption {
    protected String mLabel;
    protected String mText;

    public String getLabel() {
        return mLabel;
    }

    public void setLabel(String label) {
        mLabel = label;
    }

    public String getText() {
        return mText;
    }

    public void setText(String text) {
        mText = text;
    }
}
