package com.example.foo.mageapp.cart.total;

import com.example.foo.mageapp.cart.CartTotal;

/**
 * Created by andyk on 9/26/17.
 */

public class CartTax extends CartTotal {
    protected static final String TYPE = "tax";
}
