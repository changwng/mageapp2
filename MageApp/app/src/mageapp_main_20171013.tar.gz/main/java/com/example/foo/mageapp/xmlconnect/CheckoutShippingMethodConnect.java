package com.example.foo.mageapp.xmlconnect;

import android.content.Context;

import com.example.foo.mageapp.checkout.ShippingMethod;

/**
 * Created by andyk on 10/12/17.
 */

public class CheckoutShippingMethodConnect extends DefaultConnect {

    protected static final String TAG = CheckoutShippingMethodConnect.class.getSimpleName();

    public CheckoutShippingMethodConnect(Context context) {
        super(context);
        mPath = "xmlconnect/checkout/shippingMethods";
    }

    public ShippingMethod fetchShippingMethod() {
        String url = this.getRequestUrl();
        String xml = this.getContentByUrl(url);
        return null;
    }
}