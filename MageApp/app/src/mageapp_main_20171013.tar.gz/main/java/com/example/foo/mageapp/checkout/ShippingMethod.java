package com.example.foo.mageapp.checkout;

/**
 * Created by andyk on 10/12/17.
 */

public class ShippingMethod {

}
