package com.example.foo.mageapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.foo.mageapp.checkout.ShippingMethod;
import com.example.foo.mageapp.xmlconnect.CheckoutShippingMethodConnect;

/**
 * A simple {@link Fragment} subclass.
 */
public class CheckoutShippingMethodFragment extends Fragment {

    protected static final String TAG = CheckoutShippingMethodFragment.class.getSimpleName();
    protected ShippingMethod mShippingMethod;

    public CheckoutShippingMethodFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setRetainInstance(true);
        new ShippingMethodTask().execute();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_checkout_shipping_method, container, false);

        return v;
    }

    public static Fragment newFragment() {
        Fragment f = new CheckoutShippingMethodFragment();
        return f;
    }

    private class ShippingMethodTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... params) {
            mShippingMethod = new CheckoutShippingMethodConnect(getContext()).fetchShippingMethod();
            return null;
        }
    }
}